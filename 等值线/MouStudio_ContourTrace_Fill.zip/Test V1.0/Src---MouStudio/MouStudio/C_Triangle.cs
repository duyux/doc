﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MouStudio {
    public class C_Triangle {
        public int vv0;
        public int vv1;
        public int vv2;
    }
}
